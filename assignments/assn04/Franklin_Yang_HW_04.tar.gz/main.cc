#include "mymap.H"
#include <iostream>
#include <string>


using namespace std;

int main()
{
    
    mymap<string,int> m1;
    m1["January"] = 31;
    m1["February"] = 30;
    m1["March"] = 31;
    m1["April"] = 30;
    m1["May"] = 31;
    m1["June"] = 30;
    m1["July"] = 31;
    m1["August"] = 31;
    m1["September"] = 30;
    m1["October"] = 31;
    m1["November"] = 30;
    m1["December"] = 31;
    
    cout << m1.find("April")->second << endl; // 30
    
    cout << m1.find("Yam")->second << endl; // junk
    
    cout << m1["May"] << endl; // 31
    
    cout << (m1.find("Yam") == m1.end()? "miss" : "hit") // miss
        << endl;
        
    cout << m1["Yam"] << endl; // 0
    
    cout << (m1.find("Yam") == m1.end()? "miss" : "hit") // hit
        << endl;
    
    cout << endl;
    
    mymap<string,int> m2;
    
    m2 = m1;
    
    cout << m2.find("April")->second << endl; // 30
    
    cout << m2.find("Yam")->second << endl; // junk
    
    cout << m2["May"] << endl; // 31
    
    cout << (m2.find("Yam") == m2.end()? "miss" : "hit") // miss
        << endl;
        
    cout << m2["Yam"] << endl; // 0
    
    cout << (m2.find("Yam") == m2.end()? "miss" : "hit") // hit
        << endl;

    
    return 0;
}
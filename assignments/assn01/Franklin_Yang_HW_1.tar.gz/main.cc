#include <cstdlib>
#include <iostream>
#include <string>
#include "MyList.H"

using namespace std;

int main(int argc, char** argv)
{
    // char name[10] = "";
    string name = "";
    MyList asdf(name);
    
    asdf.print();
    
    // asdf.push_front('h');
    // asdf.push_front('g');
    // asdf.push_front('f');
    // asdf.push_front('e');
    // asdf.push_front('d');
    // asdf.push_back('a');
    
    // asdf.push_back('d');
    // asdf.push_back('e');
    // asdf.push_back('f');
    // asdf.push_back('g');
    // asdf.push_back('h');
    // // asdf.push_front('a');
    // asdf.insert_at_pos(10, 'z');
    
    MyList asdf2("cat");
    
    asdf2.print();
    
    cout << asdf.find(asdf2) << endl;
    
    // asdf2 = asdf;
    
    // MyList asdf3 = asdf2 + asdf;
    
    // asdf2.print();
    
    // asdf3.print();
    // asdf.reverse();
    
    // asdf.print();
    
    // cout << asdf[1] << endl;
    
    
    return 0;
}
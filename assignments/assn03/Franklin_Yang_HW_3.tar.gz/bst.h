// Study the following code and understand in detail how insert() and remove()
// work, and fill in correctly working code for the nine fill-in items. Turn in two
// files, one named “bst.h,” which contains your solution, and the other named
// “main.cc,” which contains your testing code.
// Note that removal is based on the simple fact that we can remove data in
// a leaf by getting rid of that leaf node, but data in an internal node is harder
// to remove. In such a case, however, either this item’s immediate successor or
// immediate predecessor is farther down the tree. So, we replace this item with
// a copy of that neighbor and recursively remove the neighbor from whichever
// subtree it is in. Think about it.

// -*- bst.h -*-

#ifndef BST_H
#define BST_H
#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>
#include <list>
#include <math.h>
using namespace std;
// #define Value     int
#define nil 0



template < typename Value >
class BST {
    
    class Node { // binary tree node
        public:
            Node* left;
            Node* right;
            Value value;
            Node( const Value v = Value() )
                : value(v), left(nil), right(nil) {}
            Value& content() { return value; }
            bool isInternal() { return left != nil && right != nil; }
            bool isExternal() { return left != nil || right != nil; }
            bool isLeaf() { return left == nil && right == nil; }
            int height() 
            {
                // returns the height of the subtree rooted at this node
                
                return height(this);
            }
            
            int height(Node *p) const
            {
                if (p == nil)
                {
                    return -1;
                }
                
                int maxHeight = 0;
                
                int leftHeight = height(p->left);
                int rightHeight = height(p->right);
                
                
                if (leftHeight <= rightHeight)
                {
                    maxHeight = rightHeight;
                }
                else
                {
                    maxHeight = leftHeight;
                }
                
                
                return  maxHeight + 1;
            }
            
            
            int size() 
            {
                // returns the size of the subtree rooted at this node,
                
                int nodeCount = 0;
                
                Node *current;
                Node *pre;
                
                if (this == nil)
                {
                    // cout << "root == nil" << endl;
                    return nodeCount;
                }
                
                current = this;
                while (current != nil)
                {
                    // cout << "current != nil" << endl;
                    if (current->left == nil)
                    {
                        // cout << "current->left == nil" << endl;
                        
                        ++nodeCount;
                        current = current->right;
                    }
                    else
                    {
                        // cout << "current->left != nil" << endl;
                        pre = current->left;
                        while(pre->right != nil && pre->right != current)
                        {
                            // cout << "pre->right != nil && pre->right != current" << endl;
                            
                            pre = pre->right;
                        }
                        
                        if (pre->right == nil)
                        {
                            // cout << "pre->right == nil" << endl;
                            pre->right = current;
                            current = current->left;
                        }
                        else
                        {
                            // cout << "pre->right != nil" << endl;
                            pre->right = nil;
                            ++nodeCount;
                            current = current->right;
                        }
                    }
                }
                
                
                
                return nodeCount;
            }
    }; // Node


    // const Node* nil; // later nil will point to a sentinel node.
    Node* root;
    int count;
    
    public:
        int size() 
        {
            // size of the overall tree.
            
            count = 0;
            
            Node *current;
            Node *pre;
            
            if (root == nil)
            {
                // cout << "root == nil" << endl;
                return count;
            }
            
            current = root;
            while (current != nil)
            {
                // cout << "current != nil" << endl;
                if (current->left == nil)
                {
                    // cout << "current->left == nil" << endl;
                    
                    ++count;
                    current = current->right;
                }
                else
                {
                    // cout << "current->left != nil" << endl;
                    pre = current->left;
                    while(pre->right != nil && pre->right != current)
                    {
                        // cout << "pre->right != nil && pre->right != current" << endl;
                        
                        pre = pre->right;
                    }
                    
                    if (pre->right == nil)
                    {
                        // cout << "pre->right == nil" << endl;
                        pre->right = current;
                        current = current->left;
                    }
                    else
                    {
                        // cout << "pre->right != nil" << endl;
                        pre->right = nil;
                        ++count;
                        current = current->right;
                    }
                }
            }
            
            return count;
        }
        bool empty() { return size() == 0; }
        void print_node( const Node* n ) 
        {
            // Print the node’s value.
            
            
            cout << "Node's value: " << n->value << endl;
        }
        
        bool search ( Value x ) 
        {
            // search for a Value in the BST and return true if it was found.
            
            Node *current = root;
            while (current != nil)
            {
                if (x > current->value)
                {
                    // cout << "x is greater than the current value." << endl;
                    current = current->right;
                    
                }
                else if (x < current->value)
                {
                    // cout << "x is less than the current value. " << endl;
                    current = current->left;
                }
                else if (x == current->value)
                {
                    // cout << "x is equal to the current value. " << endl;
                    cout << "The value was found. " << endl;
                    return true;
                }
                else
                {
                    // cout << "There is something wrong with the code." << endl;
                    return false;
                }
            }
            
            cout << "The value was not found." << endl;
            
            return false;
        }
        void preorder()const 
        {
            // Traverse and print the tree one Value per line in preorder.
            
            
            preorder(root);
            
        }
        
        void preorder(Node *p) const
        {
            
            // cout << "Size: " << p->size() << endl;
            
            
            if (p != nil)
            {
                cout << p->value << endl;
                preorder(p->left);
                preorder(p->right);
            }
        }
        
        void postorder()const 
        {
            // Traverse and print the tree one Value per line in postorder.
            
            postorder(root);
        }
        
        void postorder(Node *p) const
        {
            if (p != nil)
            {
                postorder(p->left);
                postorder(p->right);
                cout << p->value << endl;
            }
        }
        
        void inorder()const 
        {
            // Traverse and print the tree one Value per line in inorder.
            
            inorder(root);
            
        }
        
        void inorder(Node *p) const
        {
            
            if (p != nil)
            {
                inorder(p->left);
                cout << p->value << endl;
                inorder(p->right);
            }
        }
        
        Value& operator[] (int n) 
        {
            // returns reference to the value field of the n-th Node.
            // FILL IN
            
            cout << "You called the operator. How do you do?" << endl;
            
            // e.g. index 0 returns 1 for this test tree and 
            // index 1 returns 2 for this test tree
            
            int nodeCount = 0;
                
            Node *current;
            Node *pre;
            
            if (root == nil)
            {
                // cout << "root == nil" << endl;
                return root->value;
            }
            
            current = root;
            while (current != nil && nodeCount - 1 != n)
            {
                // cout << "current != nil" << endl;
                if (current->left == nil && nodeCount - 1 != n)
                {
                    // cout << "current->left == nil" << endl;
                    
                    ++nodeCount;
                    if (nodeCount - 1 != n)
                    {
                        current = current->right;
                    }
                    
                }
                else if (current->left != nil && nodeCount - 1 != n)
                {
                    // cout << "current->left != nil" << endl;
                    pre = current->left;
                    while(pre->right != nil && pre->right != current && nodeCount - 1 != n)
                    {
                        // cout << "pre->right != nil && pre->right != current" << endl;
                        
                        pre = pre->right;
                    }
                    
                    if (pre->right == nil && nodeCount - 1 != n)
                    {
                        // cout << "pre->right == nil" << endl;
                        pre->right = current;
                        current = current->left;
                    }
                    else if (pre->right != nil && nodeCount - 1 != n)
                    {
                        // cout << "pre->right != nil" << endl;
                        pre->right = nil;
                        ++nodeCount;
                        
                        if (nodeCount - 1 != n)
                        {
                            current = current->right;
                        }
                        
                    }
                }
            }
            
            
            
            return current->value;
        }
        BST() : count(0), root(nil) {}
        
        void insert( Value X ) { root = insert( X, root ); }
        
        Node* insert( Value X, Node* T ) 
        {
            // The normal binary-tree insertion procedure ...
            if ( T == nil ) {
                T = new Node( X ); // the only place that T gets updated.
            } else if ( X < T->value ) {
                T->left = insert( X, T->left );
            } else if ( X > T->value ) {
                T->right = insert( X, T->right );
            } else {
                T->value = X;
            }
            // later, rebalancing code will be installed here

            return T;
        }
        void remove( Value X ) { root = remove( X, root ); }
        
        Node* remove( Value X, Node*& T ) 
        {
            // The normal binary-tree removal procedure ...
            // Weiss’s code is faster but way more intricate.
            if ( T != nil ) 
            {
                if ( X > T->value ) 
                {
                    T->right = remove( X, T->right );
                } 
                else if ( X < T->value ) 
                {
                    T->left = remove( X, T->left );
                } 
                else 
                { // X == T->value
                    if ( T->right != nil ) 
                    {
                        Node* x = T->right;
                        while ( x->left != nil ) x = x->left;
                        T->value = x->value; // successor’s value
                        T->right = remove( T->value, T->right );
                    } 
                    else if ( T->left != nil ) 
                    {
                        Node* x = T->left;
                        while ( x->right != nil ) x = x->right;
                        T->value = x->value; // predecessor’s value
                        T->left = remove( T->value, T->left );
                    } 
                    else 
                    { // *T is external
                        delete T;
                        T = nil; // the only updating of T
                    }
                }
            }
    
            // later, rebalancing code will be installed here
            
            return T;
        }
    
        void okay( ) { okay( root ); }
        
        void okay( Node* T ) 
        {
            // diagnostic code can be installed here
            return;
        }

}; // BST
#endif

// Franklin Yang
// SID: 861157376
// 04/28/15

#include "lab4.h"
#include <cassert>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <utility>
#include <sstream>
#include <map>
#include <list>
#include <math.h>
using namespace std;

int main(int argc, char *argv[])
{
    
    if (argc < 2)
    {
        cout << "No number entered for k" << endl;
        return 0;
    }
    
    istringstream ss(argv[1]);
    int k;
    if (!(ss >> k))
    {
        cout << "Invalid number " << argv[1] << '\n';
    }
    
    // cout << "pre-order" << endl;
    
    // question1(2, 1, k);
    // question1(3, 1, k);
    
    // cout << "post-order" << endl;
    
    // question2(2, 1, k);
    // question2(3, 1, k);
    
    cout << "sorted" << endl;
    question3(k);
    
    
    return 0;
}
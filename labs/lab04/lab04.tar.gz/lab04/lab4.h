// Franklin Yang
// SID: 861157376
// 04/28/15

#ifndef LAB4_H
#define LAB4_H

#include <iostream>
#include <algorithm>
#include <vector>
#include <utility>
#include <functional>

using namespace std;

void question1(int m, int n, int k)
{
    if (m + n < k)
    {
        cout << m << " " << n << endl;
    }
    else
    {
        return;
    }
    
    question1(2*m - n, m, k);
    question1(2*m + n, m, k);
    question1(m + 2*n, n, k);
}

void question2(int m, int n, int k)
{
    if (m + n < k)
    {
        question2(2*m - n, m, k);
        question2(2*m + n, m, k);
        question2(m + 2*n, n, k);
        cout << m << " " << n << endl;
    }
}

typedef pair<int, int> Entry;
class priority_queue
{
    public:
        vector<Entry> entries;
        Entry& front()
        {
            return entries.back();
        }
        void pop()
        {
            entries.pop_back();
        }
        void push(Entry e) 
        {
            entries.push_back(e);
            for (int i = entries.size() - 1; i != 0; --i)
            {
                if (entries[i - 1].first + entries[i - 1].second < entries[i].first + entries[i].second 
                    || entries[i - 1].first < entries[i].first)
                {
                    swap(entries[i], entries[i - 1]);
                }
                // replace this comparison 
                // with code for comparing int pairs.
                else
                {
                    break; 
                }
                
                
            }
            
            // for (int i = 0; i < entries.size() - 1; ++i)
            // {
            //     if (entries[i].first + entries[i].second > entries[i + 1].first + entries[i + 1].second
            //         || entries[i].first > entries[i + 1].first)
            //     {
            //         swap(entries[i], entries[i + 1]);
            //     }
            //     else
            //     {
            //         break;
            //     }
            // }
        }
};

void question3(int m, int n, int i, int k, priority_queue &container)
{
    // cout << " m " << m << " and n " << n << " and i " << i << endl;
    if (m + n == i)
    {
        // cout << "m is " << m << " and n is " << n << endl;
        
        pair<int, int > temp2;
        temp2.first = m;
        temp2.second = n;
        container.push(temp2);
        
        // cout << container.front().first << ' ' << container.front().second << endl;
        // container.pop();
        
    }
    else
    {
        return;
    }
    
    while (i < k)
    {
        question3(2*m - n, m, i, k, container);
        question3(2*m + n, m, i, k, container);
        question3(m + 2*n, n, i, k, container);
        ++i;
    }
    
    
    
}


void question3(int k)
{
    priority_queue container;
    
    pair <int, int > temp;
    
    temp.first = 2;
    temp.second = 1;
    container.push(temp);
    
    cout << container.front().first << ' ' << container.front().second << endl;
    
    container.pop();
    
    temp.first = 3;
    temp.second = 1;
    container.push(temp);
    
    cout << container.front().first << ' ' << container.front().second << endl;
    
    container.pop();
    
    int m = 2;
    int n = 1;
    
    int i = 5;
    
    for (i = 5; i < k; ++i)
    {
        m = 2;
        n = 1;
        question3(2*m - n, m, i, k, container);
        question3(2*m + n, m, i, k, container);
        question3(m + 2*n, n, i, k, container);
        m = 3;
        n = 1;
        question3(2*m - n, m, i, k, container);
        question3(2*m + n, m, i, k, container);
        question3(m + 2*n, n, i, k, container);
        
        // cout << "entering while loop " << endl;
        
        
    }
    
    for (i = 5; i < k; ++i)
    {
        while (container.entries.size() != 0)
        {
            cout << container.front().first << " " << container.front().second << endl;
            container.pop();
        }
    }
    
}



#endif